package assignment;

public class WrongFileFormatException extends Exception {
	public WrongFileFormatException(String errMsg) {
		super(errMsg);
	}

}
